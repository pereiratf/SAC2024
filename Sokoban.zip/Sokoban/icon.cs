using Godot;
using System;

public partial class icon : Sprite2D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		
		if (Input.IsActionPressed("direita")) {
			Position = Position + new Vector2(4,0);
		} //if
		if (Input.IsActionPressed("esquerda")) {
			Position = Position + new Vector2(-4,0);
		} //if
		if (Input.IsActionPressed("cima")) {
			Position = Position + new Vector2(0,-4);
		} //if
		if (Input.IsActionPressed("baixo")) {
			Position = Position + new Vector2(0,4);
		} //if

	} //process

} //classe
